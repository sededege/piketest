import React from 'react'

const Detalle = () => {
  return (
    <div>Detalle</div>
  )
}

export default Detalle