module.exports = {
  content: ["./src/**/*.{html,js}"],
  theme: {
    extend: {
      colors: {
        pike: '#00A57C',
        pike2: '#0B0D17',
      }
    },
  },
  plugins: [],
}
